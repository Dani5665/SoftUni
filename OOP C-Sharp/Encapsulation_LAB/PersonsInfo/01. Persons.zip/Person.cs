﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonsInfo
{
    public class Person
    {
        public Person(string firstName, string lastname, int age)
        {
            FirstName = firstName;
            Lastname = lastname;
            Age = age;
        }

        public string FirstName { get; private set; }
        public string Lastname { get; private set; }
        public int Age { get; private set; }

        public override string ToString()
        {
            return $"{FirstName} {Lastname} is {Age} years old.";
        }
    }
}
