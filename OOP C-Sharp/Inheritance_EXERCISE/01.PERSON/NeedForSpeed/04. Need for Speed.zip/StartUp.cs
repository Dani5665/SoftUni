﻿namespace NeedForSpeed
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var sportCar = new SportCar(10, 10);
            sportCar.Drive(100);
            System.Console.WriteLine();
        }
    }
}
